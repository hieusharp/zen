
True Type Font: Digital Counter 7 version 1.0


EULA
-==-
The font Digital Counter 7 is freeware for home using only.


DESCRIPTION
-=========-
Original seven segments digital font but with additional internal segments to show letters and specific symbols. The font has "Italic" style. Cyrillic symbols are supported.

Files in digital_counter_7.zip:
       	readme.txt    				this file;
        digital_counter_7.ttf    		regular font;
        digital_counter_7_italic.ttf		italic font;
	digital_counter_7_screen.png		preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments, please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-==================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
http://store.esellerate.net/s.aspx?s=STR0331655240
Please contact us for additional information.
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


WHAT'S NEW?
-=========-
 * Version 1.01 (08.12.2013).
   - Height and width of the font symbols are increased.

 * Version 1.1 (10.28.2013).
   - Cyrillic symbols is added.

AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: August 1 2013